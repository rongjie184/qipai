function goroom(data){
    location.href="/lige/room/"+data.room;
}