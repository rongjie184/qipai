<?php
global $Room;
$id=ceil($data2['room']);
$Room[$id]['djs']=ceil($data2['id']);

