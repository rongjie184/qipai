<?php
//step0 游戏准备阶段
global $Room;
act('operationButton', 8, $connection);
act('initroom', $msg, $connection);
