<?php
act('timewcgx',time(),$connection);


